
import requests
from datetime import datetime
import base64
import get_data
import download_token

def upload():
    auc = '198996da-a477-4d55-b658-db40b7775356:AIjsJk_BmFsRFl31Ei0toy12ydI2awRLKVSTFDaKah69ZrQIOwDervn8g-xhH1q93BYPJcvujnP4R4EzZyiZa7s'
    auc=base64.b64encode(auc.encode()).decode()
    url = 'https://marketplace.walmartapis.com/v3/inventory'
    time=str(datetime.now())
    token=download_token.get_token()
    data=get_data.processed_data()
    #this is a dict
    headers = {
        'content-type': "application/json",
        'WM_SVC.NAME': "jtechdigital",
        'WM_QOS.CORRELATION_ID': time,
        'WM_SEC.ACCESS_TOKEN': token,
        'Authorization': 'Basic '+auc}

    for x in data:
        put_data = requests.put(url, params={}, json={
            "sku": x,
            "quantity": {"unit": "EACH", "amount": data[x]}}, headers=headers)
    return put_data.text
    #return messages for checking
