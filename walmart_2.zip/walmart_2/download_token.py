import requests
import base64
from datetime import date

def get_token():
    auc = '198996da-a477-4d55-b658-db40b7775356:AIjsJk_BmFsRFl31Ei0toy12ydI2awRLKVSTFDaKah69ZrQIOwDervn8g-xhH1q93BYPJcvujnP4R4EzZyiZa7s'
    auc=base64.b64encode(auc.encode()).decode()
    Today=str(date.today())
    url = 'https://marketplace.walmartapis.com/v3/token'
    header = {  'WM_SVC.NAME': '@sales-channel/walmart',
                'WM_QOS.CORRELATION_ID': Today,
                'Accept': 'application/json',
                'Content-Type': 'application/x-www-form-urlencoded',
                'Authorization': 'Basic '+auc}
    #infomation for requst
    token = requests.post(
        url, params={'grant_type': "client_credentials"}, headers=header)
    token=token.json()
    token = token['access_token'].encode()
    #get token
    #print(token)
    return token